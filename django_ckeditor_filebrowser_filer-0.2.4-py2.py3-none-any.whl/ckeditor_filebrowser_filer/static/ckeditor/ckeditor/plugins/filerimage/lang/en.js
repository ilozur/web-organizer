﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'filerimage', 'en', {
	name: 'Insert image',
	edit: 'Edit image',
	title: 'Image Properties',
	titleBasic: 'Basic settings',
	titleAdvanced: 'Advanced Settings',
	noFileAlt: 'No file selected',
	browse: 'Browse',
	clear: 'Clear',
	url: 'URL',
	caption: 'Caption',
	useOriginal: 'Use original image',
	crop: 'Crop',
	upscale: 'Upscale',
	autoscale: 'Autoscale',
	thumbnailOption: 'Thumbnail preset',
	alt: 'Alternative Text'
} );
